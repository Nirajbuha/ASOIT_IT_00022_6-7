<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $txt = "mr. Deep";
    $x = 10;
    $y = 20;
    $z;
    echo $txt;
    echo "ans is z=";
    echo $x*$y;
    
    ?>
</body>
</html>